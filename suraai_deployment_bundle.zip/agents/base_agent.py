from uagents import Agent, Context, Model
from loguru import logger
import asyncio
from typing import Optional, Dict, Any, List
from dotenv import load_dotenv
from agents.registry import register_agent, get_agent_address, registry
import aiohttp
import json

class BaseAgentConfig(Model):
    """Base configuration for all agents"""
    agent_name: str
    agent_description: str
    seed_phrase: Optional[str] = None

class AgentMessage(Model):
    """Standard message format between agents"""
    sender: str
    receiver: str
    message_type: str
    payload: Dict[str, Any]
    timestamp: float

class BaseSuraAgent:
    def __init__(
        self, 
        name: str, 
        seed: str, 
        port: int, 
        capabilities: List[str] = None,
        endpoint: Optional[str] = None
    ):
        load_dotenv()
        
        # Create agent WITHOUT Agentverse endpoint
        self.agent = Agent(
            name=name,
            seed=seed,
            port=port,
            endpoint=[]  # EMPTY - No Agentverse!
        )
        self.name = name
        self.capabilities = capabilities or []
        
        # Setup logging
        logger.add(
            f"logs/{name}.log",
            rotation="100 MB",
            retention="7 days",
            level="INFO"
        )
        
        logger.info(f"✅ {name} initialized (LOCAL HTTP ONLY)")
        logger.info(f"   Address: {self.agent.address}")
        logger.info(f"   Port: {port}")
        
        # Auto-register in registry
        self.register_self()
    
    def register_self(self):
        """Register this agent in the global registry"""
        try:
            register_agent(
                name=self.name,
                address=str(self.agent.address),
                port=self.agent._port,
                capabilities=self.capabilities
            )
            logger.info(f"📝 Registered {self.name} in agent registry")
        except Exception as e:
            logger.error(f"Failed to register agent: {e}")
    
    def get_peer_address(self, peer_name: str) -> Optional[str]:
        """Get another agent's address from registry"""
        address = get_agent_address(peer_name)
        if address:
            logger.debug(f"Found {peer_name} at {address[:20]}...")
        else:
            logger.warning(f"Agent {peer_name} not found in registry")
        return address
    
    async def send_to_peer(self, ctx: Context, peer_name: str, message: Model) -> bool:
        """
        Send message via DIRECT LOCAL HTTP (no Agentverse!)
        """
        # Get peer info from registry
        peer_info = registry.get_agent(peer_name)
        if not peer_info:
            logger.error(f"❌ {peer_name} not in registry!")
            logger.info("   Available agents:")
            for name in registry.get_all_agents().keys():
                logger.info(f"      - {name}")
            return False
        
        try:
            # Direct HTTP to localhost
            endpoint = f"http://localhost:{peer_info.port}/submit"
            
            logger.info(f"📤 Sending {message.__class__.__name__} to {peer_name}")
            logger.debug(f"   Target: {endpoint}")
            
            # Build payload
            payload = {
                "sender": str(self.agent.address),
                "target": peer_info.address,
                "message": message.dict(),
                "message_type": message.__class__.__name__,
            }
            
            # Send via HTTP POST
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    endpoint,
                    json=payload,
                    headers={"Content-Type": "application/json"}
                ) as resp:
                    
                    if resp.status == 200:
                        logger.info(f"✅ Sent to {peer_name}")
                        return True
                    else:
                        text = await resp.text()
                        logger.error(f"❌ HTTP {resp.status}: {text[:200]}")
                        return False
            
        except aiohttp.ClientConnectorError as e:
            logger.error(f"❌ Cannot connect to {peer_name} on port {peer_info.port}")
            logger.error(f"   Is {peer_name} running?")
            return False
        except asyncio.TimeoutError:
            logger.error(f"❌ Timeout connecting to {peer_name}")
            return False
        except Exception as e:
            logger.error(f"❌ Failed to send to {peer_name}: {e}")
            return False
    
    def get_agent(self):
        return self.agent
    
    def get_address(self):
        return self.agent.address
